from fpdf import FPDF

def read_cricket_data(filename):
    with open(filename, 'r') as file:
        data = file.readlines()
    return data

def extract_match_details(data):
    details = {}
    for line in data:
        if ':' in line:
            key, value = line.strip().split(':', 1)
            details[key.strip()] = value.strip()
    return details

def generate_pdf_report(match_details, output_file):
    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()
    pdf.set_font("Arial", style='B', size=16)
    pdf.cell(200, 10, "Cricket Match Report", ln=True, align='C')
    pdf.ln(10)
    
    pdf.set_font("Arial", size=12)
    for key, value in match_details.items():
        pdf.cell(0, 10, f"{key}: {value}", ln=True)
    
    pdf.output(output_file)
    print(f"PDF Report Generated: {output_file}")

# Main Execution
filename = "task2_cricket_stats.txt"  # Ensure this file exists in the same directory
data = read_cricket_data(filename)
match_details = extract_match_details(data)
generate_pdf_report(match_details, "cricket_match_report.pdf")

