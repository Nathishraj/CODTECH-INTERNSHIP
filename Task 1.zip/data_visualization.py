import matplotlib.pyplot as plt
import seaborn as sns

# Sample data for 5 days (Replace this with actual API data if needed)
days = ["Mon", "Tue", "Wed", "Thu", "Fri"]
temperatures = [30, 32, 29, 31, 33]  # Example temperatures
humidity_levels = [60, 65, 58, 63, 67]  # Example humidity

# Creating subplots
plt.figure(figsize=(10, 5))

# Temperature Line Graph
plt.subplot(1, 2, 1)
plt.plot(days, temperatures, marker='o', linestyle='-', color='b')
plt.xlabel("Days")
plt.ylabel("Temperature (°C)")
plt.title("Temperature Trend Over a Week")

# Humidity Bar Chart
plt.subplot(1, 2, 2)
sns.barplot(x=days, y=humidity_levels, palette="coolwarm")
plt.xlabel("Days")
plt.ylabel("Humidity (%)")
plt.title("Humidity Levels Over a Week")

plt.tight_layout()
plt.show()
