import requests

API_KEY = "a9ac1343f7cd638abe36bec97a133f0e"  # Replace with your API Key
CITY = "Chennai"
URL = f"http://api.openweathermap.org/data/2.5/weather?q={CITY}&appid={API_KEY}&units=metric"

response = requests.get(URL)
data = response.json()  # Convert response to JSON

# Extracting data
temperature = data["main"]["temp"]
humidity = data["main"]["humidity"]
wind_speed = data["wind"]["speed"]

print(f"Weather in {CITY}:")
print(f"Temperature: {temperature}°C")
print(f"Humidity: {humidity}%")
print(f"Wind Speed: {wind_speed} m/s")

